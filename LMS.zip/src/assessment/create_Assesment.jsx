import React from 'react';
import ReactDOM from 'react-dom';
import Form from '../formComponents/form'

const Createassessment = (props) => {
    return (        
          <Form />
    );
}

export default Createassessment;