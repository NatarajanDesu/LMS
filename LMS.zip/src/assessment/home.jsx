import React from 'react';
import ReactDOM from 'react-dom';

const Home = (props) => {
    return (<div>
        <h2>The Timer will come here</h2>
    </div>);
}

export default Home;