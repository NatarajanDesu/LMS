import React from 'react';
import ReactDOM from 'react-dom';
// import Form from '../formComponents/form'

const Managessessment = (props) => {
    return (
          <p>This is Manage Assessment</p>
    );
}

export default Managessessment;