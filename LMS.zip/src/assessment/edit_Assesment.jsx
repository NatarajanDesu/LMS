import React from 'react';
import ReactDOM from 'react-dom';
// import Form from '../formComponents/form'

const Editassessment = (props) => {
    return (
          <p>This is Edit Assessment</p>
    );
}

export default Editassessment;