import React from 'react';
import ReactDOM from 'react-dom';


function Header(props){
    return (        
        <div className="row">
            <header>
                <h1>Assessments Task</h1>
            </header>
        </div>
    );
};

export default Header;