import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Link } from "react-router-dom"; 


function Sidebar(props){
    return ( 
        <nav className="side_bar">
            <ul>
                <li>
                    <Link to="/createAssessment">Create Assessment</Link>
                </li>
                <li>
                    <Link to="/editAssessment">Edit Assessment</Link>
                </li>
                <li>
                    <Link to="/manageAssessment">Manage Assessment</Link>
                </li>
            </ul>
        </nav>
        
    );
};

export default Sidebar;