import React from 'react';
import ReactDOM from 'react-dom';


function Sidebar(props){
    return (        
        <div className="row">
            <nav>
                <ul>
                    <li>Create Assessment</li>
                    <li>Edit Assessment</li>
                    <li>Manage Assessment</li>
                </ul>
            </nav>
        </div>
    );
};

export default Sidebar;