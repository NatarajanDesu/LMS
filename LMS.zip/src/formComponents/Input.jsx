import React, { Component } from 'react';
import ReactDOM from 'react-dom';

const Input = (props) =>{
    return (
        <input type="textbox"
            name = {props.name} 
            placeholder={props.placeholder}
            onChange = {props.onValueChange.bind(this)}
            onBlur = {props.onBlur}
            value = {props.txtBoxValue}
        />
    );
}

export default Input;