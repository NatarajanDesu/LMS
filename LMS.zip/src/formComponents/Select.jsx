import React, { Component } from 'react';
import ReactDOM from 'react-dom';

const Select = (props) => {
    return (
        <select name={props.name} onChange = {props.onSelectValueChange} value = {props.selectValue}>
            {props.options.map((key,index) => (<option key={index}>{key}</option>))}
        </select>
    );
}

export default Select;