import React, { Component } from 'react';
import ReactDOM from 'react-dom';

const Label = (props) => {
    return (
        <label>{props.labelName}: </label>
    );
}

export default Label;