import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Input from './Input';
import Label from './Label';
import Select from './Select';

class Form extends React.Component{
    constructor(){
        super();
        this.txtBoxValueChange = this.txtBoxValueChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.dropDownHandleChange = this.dropDownHandleChange.bind(this);
        this.state = {
            selectData:['option 1','option 2','option 3']
        }
    }   

    txtBoxValueChange = (evt) =>{
        const textdata = {...this.state};
        textdata[evt.target.name] = evt.target.value;
        this.setState(textdata);
    }

    txtBoxBlur = (evt) =>{
        console.log('cursor on textBox');
    }

    handleSubmit = (evt) => {
        alert('Your favorite flavor is: ' + JSON.stringify(this.state));
        evt.preventDefault();
    }

    dropDownHandleChange=(evt)=>{
        //console.log('value changed');
        const selectData = {...this.state};
        selectData[evt.target.name] = evt.target.value;
        this.setState(selectData);
    }

    render(){
        
        console.log(this.state);
        return(
            <form onSubmit={this.handleSubmit}>
                <div className="row">
                    <Label labelName="Name"/>
                    <Input name="Name" placeholder="Enter Name" onValueChange={this.txtBoxValueChange} onBlur={this.txtBoxBlur} txtBoxValue={this.state['Name'] || ""}/>                
                </div>
                <div className="row">
                    <Label labelName="Address"/>
                    <Input name="Address" placeholder="Enter Address" onValueChange={this.txtBoxValueChange} onBlur={this.txtBoxBlur} txtBoxValue={this.state['Address'] || ""}/>                
                </div>
                <div className="row">
                    <Label labelName="Phone No"/>
                    <Input name="Phone" placeholder="Enter Nummber" onValueChange={this.txtBoxValueChange} onBlur={this.txtBoxBlur} txtBoxValue={this.state['Phone'] || ""}/>                
                </div>
                <div className="row">
                    <Label labelName="City"/>
                    <Select name="City" options={this.state.selectData} onSelectValueChange={this.dropDownHandleChange} selectValue={this.state['City'] || ""}/>               
                </div>
                <div className="row">
                    <Label labelName="State"/>
                    <Select name="State" options={this.state.selectData} onSelectValueChange={this.dropDownHandleChange} selectValue={this.state['State'] || ""}/>               
                </div>
                <input type="submit" value="Submit" />
                {/* <button onSubmit={this.submitButton}>Submit</button> */}
            </form>
        );
    }
}

export default Form;