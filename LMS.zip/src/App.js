import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom"; 
import ReactDOM from 'react-dom';
import logo from './logo.svg';
import './App.css';
import Header from './assessment/header.jsx';
import Sidebar from './assessment/sideBar';
import Home from './assessment/home';
import CreateAssesment from './assessment/create_Assesment';
import EditAssesment from './assessment/edit_Assesment';
import ManageAssesment from './assessment/manage_Assesment';
//import Form from './formComponents/form';

class App extends Component {

  state = {
    fields:['Functionality Groups','Project Name','Division','Course Name','Chapter Name', 'Assessment Name', 'Passing Thresold'],
    txtboxVal:"Nutty"
  }
  

  textboxChange = (evt) => {
    console.log(evt.target.value);
    this.setState({txtboxVal: evt.target.value})
    //console.log(this.state.txtboxVal);
  }

  render() {
    console.log(this.state.txtboxVal);
    return (   
        <div className="App">          
              <Header/>
              <div className="wrapper">
                <Sidebar/>                
                <div className="main_wrap">
                  <Switch>                    
                    <Route path="/createAssessment" component={CreateAssesment}/>
                    <Route path="/editAssessment" component={EditAssesment}/>
                    <Route path="/manageAssessment" component={ManageAssesment}/>
                    <Route exact path="/" component={Home}/>
                  </Switch>
                </div>
              </div>
        </div>
    );
  }
}

export default App;
